import React from 'react'
import './Contact.css'

const Contact = () => {
  return (
    <section id='contact'></section>
  )
}

export default Contact